r"""drive_handoff.py — chuyen file qua Google Drive giua may 1 (viet kich ban) va may 2 (sinh anh Flow).
Dung CHUNG 1 file nay tren CA HAI may — chi khac o cach goi (upload tren may 1, download tren may 2, nguoc lai
khi tra ket qua). Doc token tu D:\CLAUDE\credentials\{credentials.json,token.json} — 2 file nay phai duoc copy
sang CUNG DUONG DAN do tren may 2 (hoac sua CRED_DIR ben duoi).

Cau truc Drive da tao san (tai khoan haoviabattu@gmail.com):
  FlowHandoff/
    jobs/     <- may 1 up ho so (img_prompts.txt, characters.json) vao day
    results/  <- may 2 up anh + manifest.json ket qua vao day

Dung:
  py -3.13 drive_handoff.py upload-job <slug> <thu_muc_ho_so_local>
  py -3.13 drive_handoff.py download-job <slug> <thu_muc_dich_local>
  py -3.13 drive_handoff.py upload-result <slug> <thu_muc_img_local>
  py -3.13 drive_handoff.py download-result <slug> <thu_muc_dich_local>
  py -3.13 drive_handoff.py list-jobs
  py -3.13 drive_handoff.py list-results
"""
import sys
import os
from pathlib import Path

from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload, MediaIoBaseDownload

CRED_DIR = r"D:\CLAUDE\credentials"
TOKEN_FILE = os.path.join(CRED_DIR, "token.json")
ROOT_FOLDER_NAME = "FlowHandoff"


def get_drive():
    creds = Credentials.from_authorized_user_file(TOKEN_FILE)
    if creds.expired and creds.refresh_token:
        creds.refresh(Request())
        # ghi lai token moi (het han se tu refresh, khong can dong nay nhung luu cho nhanh lan sau)
        Path(TOKEN_FILE).write_text(creds.to_json(), encoding="utf-8")
    return build("drive", "v3", credentials=creds)


def find_folder(drive, name, parent_id=None):
    q = f"name='{name}' and mimeType='application/vnd.google-apps.folder' and trashed=false"
    if parent_id:
        q += f" and '{parent_id}' in parents"
    res = drive.files().list(q=q, fields="files(id,name)").execute()
    files = res.get("files", [])
    return files[0]["id"] if files else None


def find_or_create_folder(drive, name, parent_id=None):
    fid = find_folder(drive, name, parent_id)
    if fid:
        return fid
    meta = {"name": name, "mimeType": "application/vnd.google-apps.folder"}
    if parent_id:
        meta["parents"] = [parent_id]
    return drive.files().create(body=meta, fields="id").execute()["id"]


def get_root_ids(drive):
    root_id = find_folder(drive, ROOT_FOLDER_NAME)
    if not root_id:
        raise RuntimeError(f"Khong thay thu muc {ROOT_FOLDER_NAME} tren Drive — chay tao truoc.")
    jobs_id = find_or_create_folder(drive, "jobs", root_id)
    results_id = find_or_create_folder(drive, "results", root_id)
    return root_id, jobs_id, results_id


def upload_folder_contents(drive, local_dir, parent_id):
    """Up TAT CA file trong local_dir (khong de quy thu muc con) vao parent_id, giu nguyen ten file."""
    local_dir = Path(local_dir)
    uploaded = []
    for f in sorted(local_dir.iterdir()):
        if not f.is_file():
            continue
        media = MediaFileUpload(str(f), resumable=True)
        # xoa file cung ten cu tren Drive truoc khi up (tranh trung ban)
        q = f"name='{f.name}' and '{parent_id}' in parents and trashed=false"
        old = drive.files().list(q=q, fields="files(id)").execute().get("files", [])
        for o in old:
            drive.files().delete(fileId=o["id"]).execute()
        meta = {"name": f.name, "parents": [parent_id]}
        drive.files().create(body=meta, media_body=media, fields="id").execute()
        uploaded.append(f.name)
        print(f"  up: {f.name} ({f.stat().st_size} bytes)")
    return uploaded


def download_folder_contents(drive, remote_folder_id, local_dir):
    local_dir = Path(local_dir)
    local_dir.mkdir(parents=True, exist_ok=True)
    res = drive.files().list(q=f"'{remote_folder_id}' in parents and trashed=false",
                              fields="files(id,name)").execute()
    files = res.get("files", [])
    for f in files:
        req = drive.files().get_media(fileId=f["id"])
        dest = local_dir / f["name"]
        with open(dest, "wb") as fh:
            downloader = MediaIoBaseDownload(fh, req)
            done = False
            while not done:
                _, done = downloader.next_chunk()
        print(f"  tai: {f['name']} -> {dest}")
    return [f["name"] for f in files]


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return
    cmd = sys.argv[1]
    drive = get_drive()
    root_id, jobs_id, results_id = get_root_ids(drive)

    if cmd == "upload-job":
        slug, local_dir = sys.argv[2], sys.argv[3]
        slug_folder = find_or_create_folder(drive, slug, jobs_id)
        print(f"Upload ho so '{slug}' -> FlowHandoff/jobs/{slug}/")
        upload_folder_contents(drive, local_dir, slug_folder)

    elif cmd == "download-job":
        slug, dest_dir = sys.argv[2], sys.argv[3]
        slug_folder = find_folder(drive, slug, jobs_id)
        if not slug_folder:
            print(f"Khong thay job '{slug}' trong jobs/"); return
        print(f"Tai ho so '{slug}' -> {dest_dir}")
        download_folder_contents(drive, slug_folder, dest_dir)

    elif cmd == "upload-result":
        slug, local_dir = sys.argv[2], sys.argv[3]
        slug_folder = find_or_create_folder(drive, slug, results_id)
        print(f"Upload ket qua '{slug}' -> FlowHandoff/results/{slug}/")
        upload_folder_contents(drive, local_dir, slug_folder)

    elif cmd == "download-result":
        slug, dest_dir = sys.argv[2], sys.argv[3]
        slug_folder = find_folder(drive, slug, results_id)
        if not slug_folder:
            print(f"Khong thay ket qua '{slug}' trong results/"); return
        print(f"Tai ket qua '{slug}' -> {dest_dir}")
        download_folder_contents(drive, slug_folder, dest_dir)

    elif cmd == "list-jobs":
        res = drive.files().list(q=f"'{jobs_id}' in parents and trashed=false",
                                  fields="files(id,name)").execute()
        for f in res.get("files", []):
            print(" -", f["name"])

    elif cmd == "list-results":
        res = drive.files().list(q=f"'{results_id}' in parents and trashed=false",
                                  fields="files(id,name)").execute()
        for f in res.get("files", []):
            print(" -", f["name"])

    else:
        print(__doc__)


if __name__ == "__main__":
    main()
